Shock and Detonation Toolbox cti data files

See the Toolbox main webpage for more information:

http://shepherd.caltech.edu/EDL/PublicResources/sdt/

September 2018
